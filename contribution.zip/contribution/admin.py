# Register your models here.
from django.contrib import admin
from .models import Premium
admin.site.register(Premium)
# Register your models here.
